import { GoogleGenAI, Modality } from "@google/genai";
import { UserConfig, Message, Role } from "../types";
import { decode, decodeAudioData, getAudioContext } from "./audioUtils";

const API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: API_KEY });

// System instruction generator based on user config
const getSystemInstruction = (config: UserConfig): string => {
  return `
    You are "RAYAN LANGUAGE", an interactive language learning interface.

    **USER PROFILE:**
    - Target Language: ${config.targetLanguage}
    - Native Language: ${config.nativeLanguage}
    - Proficiency: ${config.proficiency}

    **INTERFACE & BEHAVIOR GUIDELINES:**
    
    1. **Structure as Interface**: 
       - Do not just write paragraphs. Use Markdown headers (### Title) to create distinct sections.
       - Use bolding for emphasis.
       - **Simulated Buttons**: At the end of every turn, offer 2-4 specific, actionable choices enclosed in brackets.
       - Example: [ Translate this ] [ Explain Grammar ] [ Next Exercise ]

    2. **Pedagogical Approach**:
       - **Explain Simply**: Use clear, concise language. Avoid jargon.
       - **Correction Mode**: If the user makes a mistake, create a section called "### 🛠️ Correction". Show the error, the corrected version, and a simple explanation.
       - **Examples**: Always provide 1-2 extra examples when introducing new words or rules.
       - **Check Understanding**: Ask short verification questions (e.g., "Which word means 'apple'?").

    3. **Language Balance**:
       - Primary: ${config.targetLanguage} (for immersion).
       - Secondary: ${config.nativeLanguage} (ONLY for confusing concepts, complex grammar, or if the user is struggling).
    
    **RESPONSE TEMPLATE (Flexible):**

    ### 💬 [Topic/Feedback]
    (Your main response in ${config.targetLanguage})

    ### 🧠 Learn
    (Vocabulary list or grammar note, if relevant)

    ### ⚡ Action
    (Question or exercise)

    [ Option 1 ] [ Option 2 ] [ Option 3 ]
  `;
};

export const sendMessageToGemini = async (
  history: Message[],
  newMessage: string,
  config: UserConfig
): Promise<string> => {
  try {
    const systemInstruction = getSystemInstruction(config);
    
    // Transform history for the chat API
    const chatHistory = history.map(msg => ({
      role: msg.role === Role.USER ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction,
        temperature: 0.7,
      },
      history: chatHistory
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text || "";
  } catch (error) {
    console.error("Gemini Text Error:", error);
    throw new Error("Failed to get response from tutor.");
  }
};

export const generateSpeech = async (text: string): Promise<AudioBuffer> => {
  try {
    // We clean the text to remove markdown headers/buttons before TTS so it doesn't read brackets
    const cleanText = text
      .replace(/###/g, '')
      .replace(/\*\*/g, '')
      .replace(/\[.*?\]/g, '') // Remove [Button Text]
      .replace(/- /g, '')
      .trim();

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: cleanText.substring(0, 500) }] }], // Limit length for TTS
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    
    if (!base64Audio) {
      throw new Error("No audio data received");
    }

    const audioContext = getAudioContext();
    const audioBuffer = await decodeAudioData(
      decode(base64Audio),
      audioContext,
      24000,
      1
    );

    return audioBuffer;

  } catch (error) {
    console.error("Gemini Speech Error:", error);
    throw new Error("Failed to generate speech.");
  }
};