export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export enum Language {
  ARABIC = 'Arabic',
  CHINESE = 'Chinese',
  CZECH = 'Czech',
  DANISH = 'Danish',
  DUTCH = 'Dutch',
  ENGLISH = 'English',
  FINNISH = 'Finnish',
  FRENCH = 'French',
  GERMAN = 'German',
  GREEK = 'Greek',
  HEBREW = 'Hebrew',
  HINDI = 'Hindi',
  HUNGARIAN = 'Hungarian',
  INDONESIAN = 'Indonesian',
  ITALIAN = 'Italian',
  JAPANESE = 'Japanese',
  KOREAN = 'Korean',
  NORWEGIAN = 'Norwegian',
  POLISH = 'Polish',
  PORTUGUESE = 'Portuguese',
  ROMANIAN = 'Romanian',
  RUSSIAN = 'Russian',
  SPANISH = 'Spanish',
  SWEDISH = 'Swedish',
  THAI = 'Thai',
  TURKISH = 'Turkish',
  UKRAINIAN = 'Ukrainian',
  VIETNAMESE = 'Vietnamese'
}

export enum Proficiency {
  BEGINNER = 'Beginner (A1-A2)',
  INTERMEDIATE = 'Intermediate (B1-B2)',
  ADVANCED = 'Advanced (C1-C2)'
}

export interface Message {
  id: string;
  role: Role;
  text: string;
  timestamp: number;
  isLoadingAudio?: boolean;
}

export interface UserConfig {
  nativeLanguage: Language;
  targetLanguage: Language;
  proficiency: Proficiency;
}

export interface ChatState {
  messages: Message[];
  isTyping: boolean;
}