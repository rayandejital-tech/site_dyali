import React, { useState } from 'react';
import { Message, Role } from '../types';
import { Volume2, Play, User, Bot, Loader2, Sparkles } from 'lucide-react';
import { generateSpeech } from '../services/geminiService';
import { getAudioContext } from '../services/audioUtils';

interface ChatMessageProps {
  message: Message;
  onOptionSelect?: (text: string) => void;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, onOptionSelect }) => {
  const isUser = message.role === Role.USER;
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [cachedAudio, setCachedAudio] = useState<AudioBuffer | null>(null);

  const handlePlayAudio = async () => {
    if (isPlaying || isLoadingAudio) return;

    const audioContext = getAudioContext();

    const playBuffer = (buffer: AudioBuffer) => {
      const source = audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContext.destination);
      source.onended = () => setIsPlaying(false);
      setIsPlaying(true);
      source.start();
    };

    // If we have cached audio, play it immediately
    if (cachedAudio) {
      playBuffer(cachedAudio);
      return;
    }

    try {
      setIsLoadingAudio(true);
      const audioBuffer = await generateSpeech(message.text);
      setCachedAudio(audioBuffer); // Cache for future plays
      playBuffer(audioBuffer);
    } catch (error) {
      console.error("Failed to play audio", error);
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const renderContent = (text: string) => {
    // Split content by lines for block-level formatting
    const lines = text.split('\n');
    return lines.map((line, i) => {
      const trimmed = line.trim();
      
      if (trimmed === '') return <div key={i} className="h-2" />;

      // Headers (###)
      if (trimmed.startsWith('### ')) {
        return (
          <h3 key={i} className="text-violet-300 font-bold mt-4 mb-2 text-sm uppercase tracking-wide flex items-center gap-2">
            <Sparkles className="w-3 h-3" />
            {parseInline(trimmed.replace('### ', ''))}
          </h3>
        );
      }

      // Bullets (-)
      if (trimmed.startsWith('- ')) {
        return (
          <div key={i} className="flex gap-2 ml-2 mb-1">
            <span className="text-violet-400 font-bold">•</span>
            <span className="text-slate-200">{parseInline(trimmed.replace('- ', ''))}</span>
          </div>
        );
      }

      // Standard text
      return (
        <div key={i} className="mb-1 leading-relaxed">
          {parseInline(line)}
        </div>
      );
    });
  };

  const parseInline = (text: string) => {
    // Regex to capture [Button] and **Bold**
    const regex = /(\[.*?\])|(\*\*.*?\*\*)/g;
    const parts = text.split(regex).filter(Boolean);

    return parts.map((part, index) => {
      // Bold
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={index} className="font-bold text-violet-200">{part.slice(2, -2)}</strong>;
      }
      // Button (Only if not user message)
      if (!isUser && part.startsWith('[') && part.endsWith(']')) {
        const btnText = part.slice(1, -1).trim();
        return (
          <button 
            key={index} 
            onClick={() => onOptionSelect && onOptionSelect(btnText)}
            className="inline-flex items-center mx-1 my-1 px-3 py-1 bg-violet-600/20 hover:bg-violet-600/40 border border-violet-500/50 text-violet-200 text-xs font-semibold rounded-lg transition-all cursor-pointer hover:scale-105 active:scale-95"
          >
            {btnText}
          </button>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-[95%] md:max-w-[85%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-end gap-3`}>
        
        {/* Avatar */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
          isUser ? 'bg-violet-600' : 'bg-slate-700'
        } text-white shadow-lg shadow-black/20`}>
          {isUser ? <User size={14} /> : <Bot size={14} />}
        </div>

        {/* Bubble */}
        <div className={`
          relative px-5 py-4 rounded-2xl shadow-md text-sm md:text-base
          ${isUser 
            ? 'bg-violet-600 text-white rounded-br-none' 
            : 'bg-slate-800 border border-slate-700 rounded-bl-none shadow-xl'
          }
        `}>
          <div className="flex flex-col">
             {isUser ? message.text : renderContent(message.text)}
          </div>

          {/* Audio Control for AI messages */}
          {!isUser && (
            <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center gap-2">
              <button
                onClick={handlePlayAudio}
                disabled={isLoadingAudio || isPlaying}
                className={`
                  flex items-center gap-2 text-xs font-medium px-3 py-1.5 rounded-full transition-colors border
                  ${isPlaying 
                    ? 'bg-emerald-900/30 text-emerald-400 border-emerald-800' 
                    : 'bg-slate-700/50 text-slate-400 border-slate-600/50 hover:bg-slate-600 hover:text-white'
                  }
                `}
              >
                {isLoadingAudio ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : isPlaying ? (
                  <Volume2 className="w-3 h-3 animate-pulse" />
                ) : (
                  <Play className="w-3 h-3" />
                )}
                {isLoadingAudio ? 'Generating...' : isPlaying ? 'Playing...' : 'Pronounce'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;