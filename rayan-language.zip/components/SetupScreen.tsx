import React, { useState } from 'react';
import { Language, Proficiency, UserConfig } from '../types';
import { Globe, BookOpen, User, CheckCircle } from 'lucide-react';

interface SetupScreenProps {
  onComplete: (config: UserConfig) => void;
}

const SetupScreen: React.FC<SetupScreenProps> = ({ onComplete }) => {
  const [nativeLang, setNativeLang] = useState<Language>(Language.FRENCH);
  const [targetLang, setTargetLang] = useState<Language>(Language.ENGLISH);
  const [level, setLevel] = useState<Proficiency>(Proficiency.BEGINNER);

  const handleSubmit = () => {
    onComplete({
      nativeLanguage: nativeLang,
      targetLanguage: targetLang,
      proficiency: level
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      {/* Decorative background gradients */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-violet-600/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-fuchsia-600/20 rounded-full blur-3xl"></div>
      </div>

      <div className="bg-slate-900 rounded-2xl shadow-2xl shadow-black/50 w-full max-w-lg overflow-hidden border border-slate-800 relative z-10">
        <div className="bg-slate-900 p-8 text-center border-b border-slate-800">
          <div className="mx-auto bg-violet-600/20 w-16 h-16 rounded-full flex items-center justify-center mb-4 backdrop-blur-sm border border-violet-500/30">
            <Globe className="text-violet-400 w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">RAYAN LANGUAGE</h1>
          <p className="text-slate-400">Configure your personal tutor</p>
        </div>

        <div className="p-8 space-y-6">
          
          {/* Native Language */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-semibold text-slate-300">
              <User className="w-4 h-4 mr-2 text-violet-400" />
              I speak (Native Language)
            </label>
            <div className="relative">
              <select 
                value={nativeLang}
                onChange={(e) => setNativeLang(e.target.value as Language)}
                className="w-full p-3 bg-slate-800 border border-slate-700 text-white rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-violet-500 transition-all outline-none appearance-none hover:border-slate-600"
              >
                {Object.values(Language).map((l) => (
                  <option key={l} value={l} className="bg-slate-800">{l}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Target Language */}
          <div className="space-y-2">
            <label className="flex items-center text-sm font-semibold text-slate-300">
              <BookOpen className="w-4 h-4 mr-2 text-violet-400" />
              I want to learn
            </label>
            <select 
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value as Language)}
              className="w-full p-3 bg-slate-800 border border-slate-700 text-white rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-violet-500 transition-all outline-none appearance-none hover:border-slate-600"
            >
              {Object.values(Language).map((l) => (
                <option key={l} value={l} disabled={l === nativeLang} className="bg-slate-800">
                  {l}
                </option>
              ))}
            </select>
          </div>

          {/* Level */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-300 mb-3">My current level</label>
            <div className="grid grid-cols-1 gap-3">
              {Object.values(Proficiency).map((p) => (
                <button
                  key={p}
                  onClick={() => setLevel(p)}
                  className={`p-3 rounded-xl border-2 text-left transition-all flex items-center justify-between ${
                    level === p 
                      ? 'border-violet-500 bg-violet-500/10 text-violet-300 font-medium' 
                      : 'border-transparent bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                  }`}
                >
                  <span>{p}</span>
                  {level === p && <CheckCircle className="w-5 h-5 text-violet-500" />}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleSubmit}
            className="w-full py-4 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl shadow-lg shadow-violet-900/20 transform transition hover:-translate-y-0.5 active:translate-y-0"
          >
            Start Learning
          </button>
        </div>
      </div>
    </div>
  );
};

export default SetupScreen;