import React, { useState, useRef, useEffect } from 'react';
import { Send, RefreshCw, Zap, Book, MessageSquare, Menu, ArrowLeft, PenTool, Sparkles, GraduationCap } from 'lucide-react';
import { Message, Role, UserConfig, ChatState } from './types';
import SetupScreen from './components/SetupScreen';
import ChatMessage from './components/ChatMessage';
import { sendMessageToGemini } from './services/geminiService';

const App: React.FC = () => {
  const [config, setConfig] = useState<UserConfig | null>(null);
  const [state, setState] = useState<ChatState>({
    messages: [],
    isTyping: false
  });
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.messages]);

  // Initial greeting when config is set
  useEffect(() => {
    if (config && state.messages.length === 0) {
      handleSend("Start the session.", true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config]);

  const handleSend = async (text: string, isInitial: boolean = false) => {
    if ((!text.trim() && !isInitial) || !config) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      text: text,
      timestamp: Date.now()
    };

    if (!isInitial) {
      setState(prev => ({
        ...prev,
        messages: [...prev.messages, userMessage],
        isTyping: true
      }));
      setInputText('');
    } else {
       setState(prev => ({ ...prev, isTyping: true }));
    }

    try {
      const historyToUse = isInitial ? [] : [...state.messages, userMessage];
      // For initial message, we give a system-like prompt to kick off the "interface" mode
      const promptToSend = isInitial 
        ? "Initialize the learning session. Introduce yourself briefly, then propose 3 clear options for me to start (e.g., [ Vocabulary ], [ Conversation ], [ Grammar ])." 
        : text;

      const aiResponseText = await sendMessageToGemini(historyToUse, promptToSend, config);

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: Role.MODEL,
        text: aiResponseText,
        timestamp: Date.now()
      };

      setState(prev => ({
        messages: isInitial ? [aiMessage] : [...prev.messages, userMessage, aiMessage],
        isTyping: false
      }));

    } catch (error) {
      console.error(error);
      setState(prev => ({ ...prev, isTyping: false }));
    }
  };

  const handleQuickAction = (action: string) => {
    const actions: {[key: string]: string} = {
      'lesson': `Give me a mini-lesson.`,
      'explain': `Explain the grammar of the last sentence simply.`,
      'correct': `Correct my last message and explain errors.`,
      'natural': `How would a native speaker say that?`,
      'exercise': `Give me a practice exercise.`
    };
    if (actions[action]) {
        handleSend(actions[action]);
    }
  };

  if (!config) {
    return <SetupScreen onComplete={setConfig} />;
  }

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden text-slate-200">
      
      {/* Sidebar - Desktop */}
      <div className="hidden md:flex flex-col w-64 bg-slate-900 border-r border-slate-800">
        <div className="p-6 border-b border-slate-800">
           <div className="flex items-center gap-3 text-violet-400 font-bold text-xl">
             <Zap className="fill-current" />
             RAYAN LANGUAGE
           </div>
        </div>
        
        <div className="flex-1 p-4 space-y-6">
          <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl">
             <h3 className="text-xs font-semibold text-violet-400 uppercase tracking-wider mb-2">Current Session</h3>
             <div className="space-y-2">
                <div className="flex items-center text-sm text-slate-300">
                   <span className="w-2 h-2 rounded-full bg-violet-500 mr-2"></span>
                   Target: <span className="font-semibold ml-1 text-white">{config.targetLanguage}</span>
                </div>
                <div className="flex items-center text-sm text-slate-300">
                   <span className="w-2 h-2 rounded-full bg-blue-500 mr-2"></span>
                   Native: <span className="font-semibold ml-1 text-white">{config.nativeLanguage}</span>
                </div>
                <div className="flex items-center text-sm text-slate-300">
                   <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2"></span>
                   Level: <span className="font-semibold ml-1 text-white">{config.proficiency.split(' ')[0]}</span>
                </div>
             </div>
          </div>
          
          <div className="space-y-1">
             <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-2">Quick Actions</h3>
             <button onClick={() => handleQuickAction('lesson')} className="w-full flex items-center px-3 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-violet-300 rounded-lg transition-colors">
               <GraduationCap className="w-4 h-4 mr-3" /> Mini Lesson
             </button>
             <button onClick={() => handleQuickAction('explain')} className="w-full flex items-center px-3 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-violet-300 rounded-lg transition-colors">
               <Book className="w-4 h-4 mr-3" /> Explain Grammar
             </button>
             <button onClick={() => handleQuickAction('correct')} className="w-full flex items-center px-3 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-violet-300 rounded-lg transition-colors">
               <RefreshCw className="w-4 h-4 mr-3" /> Correct Me
             </button>
             <button onClick={() => handleQuickAction('natural')} className="w-full flex items-center px-3 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-violet-300 rounded-lg transition-colors">
               <Sparkles className="w-4 h-4 mr-3" /> Make Natural
             </button>
             <button onClick={() => handleQuickAction('exercise')} className="w-full flex items-center px-3 py-2 text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-violet-300 rounded-lg transition-colors">
               <PenTool className="w-4 h-4 mr-3" /> Practice Exercise
             </button>
          </div>
        </div>

        <div className="p-4 border-t border-slate-800">
           <button 
             onClick={() => setConfig(null)}
             className="flex items-center text-sm font-medium text-slate-500 hover:text-red-400 transition-colors"
           >
             <ArrowLeft className="w-4 h-4 mr-2" /> Change Settings
           </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full relative bg-slate-950">
        
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 bg-slate-900 border-b border-slate-800 shadow-sm z-10">
           <div className="font-bold text-violet-400 flex items-center gap-2">
             <Zap className="w-5 h-5 fill-current" /> RAYAN LANGUAGE
           </div>
           <button onClick={() => setConfig(null)} className="text-slate-400 hover:text-white">
             <ArrowLeft className="w-5 h-5" />
           </button>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scrollbar-hide space-y-4">
          {state.messages.map((msg) => (
            <ChatMessage 
              key={msg.id} 
              message={msg} 
              onOptionSelect={(text) => handleSend(text)} 
            />
          ))}
          
          {state.isTyping && (
            <div className="flex justify-start">
              <div className="bg-slate-800 border border-slate-700 px-4 py-3 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-2">
                 <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0ms'}}></div>
                 <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '150ms'}}></div>
                 <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '300ms'}}></div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 md:p-6 bg-slate-900 border-t border-slate-800">
          <div className="max-w-4xl mx-auto relative">
             {/* Mobile Quick Actions Row */}
             <div className="md:hidden flex gap-2 mb-3 overflow-x-auto pb-1 scrollbar-hide">
               <button onClick={() => handleQuickAction('lesson')} className="flex-shrink-0 px-3 py-1 bg-slate-800 text-violet-300 text-xs font-medium rounded-full border border-slate-700">Mini Lesson</button>
               <button onClick={() => handleQuickAction('explain')} className="flex-shrink-0 px-3 py-1 bg-slate-800 text-violet-300 text-xs font-medium rounded-full border border-slate-700">Explain</button>
               <button onClick={() => handleQuickAction('correct')} className="flex-shrink-0 px-3 py-1 bg-slate-800 text-violet-300 text-xs font-medium rounded-full border border-slate-700">Correct</button>
               <button onClick={() => handleQuickAction('natural')} className="flex-shrink-0 px-3 py-1 bg-slate-800 text-violet-300 text-xs font-medium rounded-full border border-slate-700">Natural</button>
               <button onClick={() => handleQuickAction('exercise')} className="flex-shrink-0 px-3 py-1 bg-slate-800 text-violet-300 text-xs font-medium rounded-full border border-slate-700">Exercise</button>
             </div>

             <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend(inputText)}
                  placeholder={`Type in ${config.targetLanguage}...`}
                  className="flex-1 bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-sm rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-violet-500 block w-full p-4 transition-all outline-none"
                  disabled={state.isTyping}
                />
                <button 
                  onClick={() => handleSend(inputText)}
                  disabled={!inputText.trim() || state.isTyping}
                  className="p-4 bg-violet-600 hover:bg-violet-700 disabled:bg-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed rounded-xl transition-all text-white shadow-md shadow-black/30 hover:shadow-lg active:scale-95"
                >
                  <Send className="w-5 h-5" />
                </button>
             </div>
             <p className="text-center text-xs text-slate-500 mt-2">
               AI can make mistakes. Practice regularly.
             </p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default App;